module.exports = {
  project: {
    ios: {},
    android: {},
  },
};
